﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace freshmanOrientation_G3

{
    
    public partial class manageAdmin : System.Web.UI.Page
    {
        string constring = @"Data Source=KK_PC\SQLEXPRESS;Initial Catalog=PSB;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Admin_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(constring))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Admin_TB", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Admin.DataSource = dt;
                Admin.DataBind();
            }

        }
    }
}